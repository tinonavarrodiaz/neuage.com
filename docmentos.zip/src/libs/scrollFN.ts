export const scrollFunction = (scrollHeight:number) =>{
  const screenHeight = window.innerHeight as number
  window.addEventListener('scroll', e=>{
    const scrollY = window.scrollY as number
    if (scrollY >= screenHeight/2 && scrollY<screenHeight){
      document.body.classList.add('show-images')
      document.body.classList.remove('show-screen-white')
    }else if (scrollY >= screenHeight){
      document.body.classList.add('show-screen-white')
    }else{
      document.body.classList.remove('show-images')
    }
  })
}
